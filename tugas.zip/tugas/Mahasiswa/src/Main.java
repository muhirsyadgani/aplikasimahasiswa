import com.Mahasiswa.gui.MainScreen;

public class Main {
    public static void main(String[] args) {
        MainScreen mainScreen = new MainScreen();
    }
}
