package com.Mahasiswa.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;

public class MainScreen extends JFrame{
    private JTextField textField1Nama;
    private JTextField textField2NIm;
    private JTextField textField3Ipk;
    private JTextField textField4Angkatan;
    private JButton tambahButton;
    private JButton hapusButton;
    private JTable table1;
    private DefaultTableModel defaultTableModel = new DefaultTableModel();
    private JPanel panelMain;
    private JButton updateButton;
    private JButton cariMahasiswaButton;
    private JTextField textField1CariMahasiswa;

    private String url = "jdbc:mysql://localhost:3306/db_mahasiswa";
    private  String username = "testing";
    private  String pass = "123";

    public MainScreen(){
        JFrame frame = new JFrame();
        frame.add(panelMain);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(470,470);
        TampilkanMahasiswa(getData());
        try{
            Driver driver = new com.mysql.cj.jdbc.Driver();
            DriverManager.registerDriver(driver);
        }catch (SQLException s){
            System.out.println(s);
        }

        tambahButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nama = textField1Nama.getText();
                int nim = Integer.parseInt(textField2NIm.getText());
                String Angkatan = textField4Angkatan.getText();
                double ipk = Double.parseDouble(textField3Ipk.getText());
                try{
                    Connection connection = DriverManager.getConnection(url,username,pass);
                    Statement statement = connection.createStatement();
                    String sql = "INSERT INTO tb_mahasiswa (nama, nim, angkatan, ipk) VALUES ('" + nama + "', '" + nim + "', '" + Angkatan + "', " + ipk + ")";
                    statement.execute(sql);
                }catch (SQLException s){
                    System.out.println(s);
                }
                TampilkanMahasiswa(getData());
            }
        });
        hapusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nim = textField2NIm.getText();
                if (nim.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "NIM tidak boleh kosong", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Integer nimParsing;
                try {
                    nimParsing = Integer.parseInt(nim);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "NIM harus berupa angka", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    Connection connection = DriverManager.getConnection(url, username, pass);
                    String sql = "DELETE FROM tb_mahasiswa WHERE nim = ?";
                    PreparedStatement preparedStatement = connection.prepareStatement(sql);
                    preparedStatement.setInt(1, nimParsing);

                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Data berhasil dihapus", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Data tidak ditemukan", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    connection.close();
                } catch (SQLException s) {
                    JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat menghapus data: " + s.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }

                TampilkanMahasiswa(getData());
            }
        });
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nama = textField1Nama.getText();
                int nim = Integer.parseInt(textField2NIm.getText());
                String angkatan = textField4Angkatan.getText();
                double ipk = Double.parseDouble(textField3Ipk.getText());

                try {
                    Connection connection = DriverManager.getConnection(url, username, pass);
                    String sql = "UPDATE tb_mahasiswa SET nama = ?, angkatan = ?, ipk = ? WHERE nim = ?";
                    PreparedStatement pstmt = connection.prepareStatement(sql);
                    pstmt.setString(1, nama);
                    pstmt.setString(2, angkatan);
                    pstmt.setDouble(3, ipk);
                    pstmt.setInt(4, nim);
                    int rowsUpdated = pstmt.executeUpdate();
                    if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Data tidak ditemukan", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                } catch (SQLException s) {
                    JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat memperbarui data: " + s.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }

                TampilkanMahasiswa(getData());
            }
        });

        cariMahasiswaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nim = textField1CariMahasiswa.getText();
                if (nim.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "NIM tidak boleh kosong", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Integer nimParsing;
                try {
                    nimParsing = Integer.parseInt(nim);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "NIM harus berupa angka", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    Connection connection = DriverManager.getConnection(url, username, pass);
                    String sql = "SELECT * FROM tb_mahasiswa WHERE nim = ?";
                    PreparedStatement pstmt = connection.prepareStatement(sql);
                    pstmt.setInt(1, nimParsing);
                    ResultSet resultSet = pstmt.executeQuery();

                    if (resultSet.next()) {
                        String nama = resultSet.getNString("nama");
                        String angkatan = resultSet.getNString("angkatan");
                        double ipk = resultSet.getDouble("ipk");

                        // Menampilkan data yang ditemukan ke dalam form
                        textField1Nama.setText(nama);
                        textField2NIm.setText(String.valueOf(nimParsing));
                        textField4Angkatan.setText(angkatan);
                        textField3Ipk.setText(String.valueOf(ipk));

                        JOptionPane.showMessageDialog(null, "Data ditemukan", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Data tidak ditemukan", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    connection.close();
                } catch (SQLException s) {
                    JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat mencari data: " + s.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

    }
    public void TampilkanMahasiswa(ArrayList<Mahasiswa> daTa) {
        Object[][] data = new Object[daTa.size()][2];
        for (int i = 0; i < daTa.size(); i++) {
            data[i] = new Object[]{
                    daTa.get(i).getNama(),
                    daTa.get(i).getNim(),
                    daTa.get(i).getAngkatan(),
                    daTa.get(i).getIpk()
            };
        }
        defaultTableModel = new DefaultTableModel(
                data,
                new String[]{"Nama","Nim","Angkatan","IPK"}
        );
        table1.setModel(defaultTableModel);
    }
    public ArrayList<Mahasiswa> getData(){
        ArrayList<Mahasiswa> mahasiswas = new ArrayList<>();
        try{
            Connection connection = DriverManager.getConnection(url,username,pass);
            Statement statement = connection.createStatement();
            String sql =  "SELECT * FROM tb_mahasiswa";
            ResultSet resultSet = statement.executeQuery(sql);
            while(resultSet.next()){
                String nama =resultSet.getNString("nama");
                Integer nim = resultSet.getInt("nim");
                int nimParse = Integer.parseInt(String.valueOf(nim));
                String angkatan = resultSet.getNString("angkatan");
                Double ipk = resultSet.getDouble("ipk");
                Mahasiswa mahasiswa = new Mahasiswa(nama,nimParse,angkatan,ipk);
                mahasiswas.add(mahasiswa);
            }
        }catch (SQLException s){
            System.out.println(s);
        }
        return mahasiswas;
    }
    public void cleanForm(){

    }
}

