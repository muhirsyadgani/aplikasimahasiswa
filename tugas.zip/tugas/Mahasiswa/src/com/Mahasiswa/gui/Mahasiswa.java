package com.Mahasiswa.gui;

public class Mahasiswa {
    private String nama;
    private int nim;
    private String angkatan;
    private double ipk;


    public Mahasiswa(String nama, int nim, String angkatan, double ipk) {
        this.nama = nama;
        this.nim = nim;
        this.angkatan = angkatan;
        this.ipk = ipk;
    }

    public String getNama(){
        return nama;
    }
    public void setNama (){
        this.nama = nama;
    }

    public int getNim(){
        return nim;
    }
    public void setNim(){
        this.nim = nim;
    }

    public String getAngkatan(){
        return angkatan;
    }
    public void setAngkatan(){
        this.angkatan = angkatan;
    }

    public double getIpk(){
        return ipk;
    }
    public void setIpk(double ipk){
        this.ipk = ipk;
    }
}
